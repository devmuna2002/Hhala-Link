// Shared Expo push fan-out: every Activity-screen notification row should
// also arrive as a system push. Best-effort everywhere — these helpers
// never throw and must never fail the request that triggered them.
function extractExpoToken(stored) {
    if (!stored) return null;
    if (typeof stored === "string") {
        const trimmed = stored.trim();
        if (trimmed.startsWith("ExponentPushToken")) return trimmed;
        try {
            return extractExpoToken(JSON.parse(trimmed));
        } catch {
            return null;
        }
    }
    if (typeof stored === "object") {
        if (typeof stored.expo === "string" && stored.expo.startsWith("ExponentPushToken")) return stored.expo;
        if (typeof stored.token === "string" && stored.token.startsWith("ExponentPushToken")) return stored.token;
    }
    return null;
}

async function sendExpoPush({ token, title, body, data }) {
    if (!token) return null;
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 10000);
    try {
        const response = await fetch("https://exp.host/--/api/v2/push/send", {
            method: "POST",
            headers: { Accept: "application/json", "Content-Type": "application/json" },
            body: JSON.stringify({
                to: token,
                sound: "default",
                title: String(title || "Hlala Link").slice(0, 100),
                body: String(body || "You have a new update.").slice(0, 500),
                data: data && typeof data === "object" && !Array.isArray(data) ? data : {},
                channelId: "default",
                priority: "high",
                ttl: 60
            }),
            signal: controller.signal
        });
        const result = await response.json().catch(() => null);
        const ticket = Array.isArray(result?.data) ? result.data[0] : result?.data;
        return ticket?.status === "ok" ? ticket : null;
    } catch {
        return null;
    } finally {
        clearTimeout(timeout);
    }
}

// Resolve the recipient's stored token and push. Resolves the ticket on
// success, null when there is no token or delivery fails. Never throws.
async function pushToUser(pool, userId, { title, body, data }) {
    if (!pool || !userId) return null;
    try {
        const profile = await pool.query("SELECT push_token FROM profiles WHERE id = $1", [userId]);
        const token = extractExpoToken(profile.rows[0]?.push_token);
        if (!token) return null;
        return await sendExpoPush({ token, title, body, data });
    } catch (error) {
        console.error("Expo push failed:", error?.message || error);
        return null;
    }
}

module.exports = { extractExpoToken, sendExpoPush, pushToUser };
